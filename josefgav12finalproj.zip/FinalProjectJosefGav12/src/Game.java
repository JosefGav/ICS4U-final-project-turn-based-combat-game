
/*
 * File Starts the game based off a list of selected characters
 * Josef Gavronskiy FINAL PROJ
 * ICS4U 2024/2025
 * */

public class Game {
	public void startGame(PlayableUnit[] selectedCharacters) {
		Map map = new Map(24,24,selectedCharacters);
	}
}
